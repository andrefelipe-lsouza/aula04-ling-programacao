#include <stdio.h>
#include <string.h>

//Fun��o para inverter uma string usando ponteiros
void inverter_string(char *str){
	//implemente usando dois ponteiros
	//Um no inicio e outro no fim da string
	int len;//variavel que guarda tamanho da string
	char *inicio;//ponteiro par o primeiro carcaatere
	char *fim;//ponteiro paara o ultimo
	char temp;//variavel auxiliar para troca
	
	if(str == NULL) return;//string = NULL ent�o sai da fun��o
	
	len = strlen(str); //calcula o tamanho da string
	
	if(len <= 1) return;//se for vazio ou tiver 1 caractere � precisa inverter
	
	inicio = str;//aponta para o primeiro caractere 
	
	fim = str + len - 1;//aponta para o segundo caractere 
	
while (inicio < fim){
	temp = *inicio; //guarda caractere do inicio fim
	*inicio = *fim;//coloca o caractere do inicio no fim
	*fim = temp;//coloca o caractere guardado no fim
	
	inicio++;//incrementa ponteiro de inicio
	fim--;//decrementa ponteiro do fim
  }
} 
int main(void){
	char texto[] = "PONTEIROS";
	
	printf("String original: %s\n", texto);
	inverter_string(texto);
	printf("String invertida: %s\n", texto);
	
	return 0;
}
