#include <stdio.h>

//Func�o para calcular estatisticaas de um array de notas
void calcular_estatisticas(float *notas, int quantidade, 
float *media, float *maior, float *menor){
	
	//implemente esta fun��o
	//calcule m�dia, maior, menor nota usando
	float soma = 0.0;//variavel que armazena a soma das notas
	float valor;//variavel auxiliar para cada nota
	int i;//variavel que percorre o vetoe
	
	*maior = *notas;//inicializa com o primeiro valor
	*menor = *notas;//inicializa com o primeiro valor
	
	for(i = 0; i < quantidade; i++){
		valor = *(notas + i);//acessando via ponteiro
		soma += valor;//acumula para calcular a m�dia
		
		if(valor > *maior){//verifica se a nota foi a maior encontrada
			*maior = valor;
		}
		if(valor < *menor){//verifica se a nota foi a menor encontrada
			*menor = valor;
		}
   }
   *media = soma/quantidade;//calcula a m�dia o
}
int main(void){
	float notas[] = {8.5, 7.2, 9.1, 6.8, 8.9, 7.7, 9.5, 8.2};
	int qtd_notas = sizeof(notas) / sizeof(notas[0]);//calculo automatico da quantidade de notas
	float media, maior, menor;
	int i;
	
	calcular_estatisticas(notas, qtd_notas, &media, &maior, &menor);//chama a fun��o que calcula as estatisticas
	
	//impress�o
	printf(" === RELATORIOS DE NOTAS ===");
	printf("\n Notas: ");
	for(i = 0; i < qtd_notas; i++){
		printf("%.1f ", notas[i]);
	}
	printf("\n");
	printf(" Media: %.2f\n", media);
	printf(" Maior nota: %.2f\n", maior);
	printf(" Menor nota: %.2f\n", menor);
	
	return 0;
}
