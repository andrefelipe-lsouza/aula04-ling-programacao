#include <stdio.h>

int main(){
	float salario = 2500.50;
	float *ponteiro_salario;
	
	//Fa�a o ponteiro apontar para salario
	ponteiro_salario = &salario;
	
	//Imprima o valor usando o ponteiro
	printf("Salario: %.2f\n", *ponteiro_salario);
	
	//Modifique o valor do salario atraves do ponteiro
	*ponteiro_salario = 3000.00;
	
	//Imprima o valor
	printf("Novo salario: %.2f\n", salario);
	
	return 0;
}
