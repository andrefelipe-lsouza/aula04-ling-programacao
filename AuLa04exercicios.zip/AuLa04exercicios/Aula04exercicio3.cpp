#include <stdio.h>

//implemente esta fun��o usando apenas ponteiros
int encontrar_maior(int *array, int tamanho){
    //DICA: use um ponteiro para percorrer o Array
    //e outro para guardar o endere�o do maior elemento
	int *p = array;
	int *maior = array;
	
	for(int i=0; i < tamanho; i++){
		if(*(p+i)>*maior){
			maior = p+i;
		}  
	}
	return *maior;
}

int main(){
	int numeros[] = {45, 23, 78, 12, 67, 34, 89, 56};
	int tamanho = sizeof(numeros) / sizeof(numeros[0]);
	
	int maior = encontrar_maior(numeros, tamanho);
	
	printf("Array: ");
	for(int i = 0; i < tamanho; i++){
		printf("%d ", numeros[i]);
	}
	printf("\nMaior elemento: %d\n", maior);
	
	return 0;
}
